import javax.swing.*;
class test{
public static void main(String[] args) {
		  typing_tutor t= new typing_tutor();
		  t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  t.setSize(1600,600);
		  t.setVisible(true);
	 }
}